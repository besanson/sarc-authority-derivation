#!/usr/bin/env python3
"""External command recorder; never writes instrumentation into the checkout."""
import argparse
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument("label")
p.add_argument("command")
p.add_argument("--cwd", default="/home/user/workspace")
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parent
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
t = time.monotonic()
out = root / (a.label + ".log")
with out.open("wb") as f:
    result = subprocess.run(["/bin/bash", "-o", "pipefail", "-c", a.command],
                            cwd=a.cwd, stdout=f, stderr=subprocess.STDOUT)
record = dict(label=a.label, command=a.command, cwd=a.cwd, start_utc=start,
              elapsed_seconds=round(time.monotonic()-t, 6),
              exit_code=result.returncode, output_file=out.name,
              output_sha256=hashlib.sha256(out.read_bytes()).hexdigest())
if pathlib.Path(a.cwd).name == "sarc-authority-derivation":
    snapshot = root / "snapshots" / a.label
    for pattern in ("out/checkers/*.json", "out/pytest-junit.xml",
                    "out/reproducibility-report.json",
                    "paper5-authority-derivation-draft-v0.5-populated.md"):
        for src in pathlib.Path(a.cwd).glob(pattern):
            dest = snapshot / src.relative_to(a.cwd)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
with (root / "commands.jsonl").open("a") as f:
    f.write(json.dumps(record) + "\n")
print(json.dumps(record), flush=True)
print(out.read_text(errors="replace"), end="", flush=True)
raise SystemExit(result.returncode)
