#!/usr/bin/env python3
"""Assemble the reproduction report from captured execution evidence."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess

E = pathlib.Path(__file__).resolve().parent
R = E.parent / "sarc-authority-derivation"
sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=R, text=True).strip()
assert sha == "4a9676966aecb3d18cec6411decd5b9cfa8a7320"
records = [json.loads(line) for line in (E / "commands.jsonl").read_text().splitlines()]
by_label = {r["label"]: r for r in records}
for r in records:
    assert hashlib.sha256((E / r["output_file"]).read_bytes()).hexdigest() == r["output_sha256"], r["label"]
for label in ["07-bootstrap", "08-quick-reproduce", "10-ch-b1", "11-ch-c1",
              "15-install-build", "16-package-smoke-retry", "17-retained-build",
              "18-retained-wheel-install", "19-wheel-import-provenance", "20-integrity"]:
    assert by_label[label]["exit_code"] == 0, label
assert by_label["09-package-smoke-test"]["exit_code"] == 2
subprocess.run(["git", "diff", "--exit-code", "--", ".", ":(exclude)out"], cwd=R, check=True)
changed = subprocess.check_output(["git", "diff", "--name-only"], cwd=R, text=True).splitlines()
assert set(changed) == {
    "out/checkers/ch_b2_check.json", "out/checkers/ch_c2_check.json",
    "out/checkers/derivation_output.json", "out/checkers/derivation_output_v2.json",
}
b1 = json.loads((R / "out/checkers/ch_b1_check.json").read_text())
c1 = json.loads((R / "out/checkers/ch_c1_check.json").read_text())
assert b1["core_cardinality"] == 6 and not b1["is_core_sufficient"]
assert len(b1["minimum_reducts"]) == 2 and b1["minimum_reduct_cardinality"] == 7
assert c1["core_cardinality"] == 4 and not c1["is_core_sufficient"]
assert c1["minimum_cardinality"] == 9 and c1["minimum_cardinality_contracts_found_count"] == 5
assert b1["supported"] and c1["supported"]
quick = (E / "08-quick-reproduce.log").read_text()
for value in ["252 passed in 275.64s", "formal double-run byte-identical: OK",
              "populated draft byte-identical to freshly regenerated: OK",
              "quick-reproduce: ALL CHECKS PASS"]:
    assert value in quick
expected = re.findall(r"\| `([^`]+)` \| `([a-f0-9]{64})` \|", (R / "REPRODUCTION.md").read_text())
assert len(expected) == 6
generated = {path for path, _ in expected[:4]}
hash_rows = []
verification = []
for path, exp in expected:
    actual = hashlib.sha256((R / path).read_bytes()).hexdigest()
    rerun = path in generated
    verification.append(dict(file=path, expected=exp, actual=actual,
                             regenerated=rerun, matches=actual == exp))
    if rerun:
        hash_rows.append(f"| `{path}` | `{actual}` | {'MATCH' if actual == exp else 'MISMATCH'} |")
    else:
        hash_rows.append(f"| `{path}` | Not generated; retained committed file, not reproduction evidence | Not evaluated |")
assert [v["file"] for v in verification if v["regenerated"] and not v["matches"]] == ["out/checkers/ch_c2_check.json"]
(E / "verification.json").write_text(json.dumps({
    "commit": sha, "source_and_configuration_unchanged": True,
    "tracked_generated_outputs_changed": changed, "expected_hash_comparison": verification,
    "command_log_hashes_verified": len(records),
    "independent_human_reproduction": False,
    "host_history_attested": False, "issue_filed": False,
}, indent=2) + "\n")
diff = subprocess.check_output(["git", "diff", "--", "out"], cwd=R, text=True)
(E / "generated-output-diff.patch").write_text(diff)
timing_labels = [
    ("07-bootstrap", "Bootstrap, including imported-baseline release check"),
    ("08-quick-reproduce", "Quick reproduce"),
    ("09-package-smoke-test", "Exact wheel target, initial failure"),
    ("10-ch-b1", "Exact CH-B1 section-6 snippet"),
    ("11-ch-c1", "Standalone CH-C1 checker"),
    ("15-install-build", "Environment-only build prerequisite"),
    ("16-package-smoke-retry", "Unchanged wheel target, retry"),
    ("17-retained-build", "Additional retained sdist and wheel build"),
    ("18-retained-wheel-install", "Additional fresh wheel-only environment/install"),
    ("19-wheel-import-provenance", "Wheel import paths, exact smoke example and CLI help"),
]
timing_rows = []
for label, description in timing_labels:
    rec = by_label[label]
    s = rec["elapsed_seconds"]
    timing_rows.append(f"| {description} | {s:.3f} | {int(s//60)}m {s%60:.3f}s | {rec['exit_code']} |")
wheel = next((E / "distributions").glob("*.whl"))
sdist = next((E / "distributions").glob("*.tar.gz"))
wheel_hash = hashlib.sha256(wheel.read_bytes()).hexdigest()
sdist_hash = hashlib.sha256(sdist.read_bytes()).hexdigest()
seconds = by_label["08-quick-reproduce"]["elapsed_seconds"]
delta = seconds - 2874.14
report = f"""# Reproduction report: 4a96769 on Ubuntu 26.04 / Python 3.12.13

Technical result: bootstrap, quick reproduction, CH-B1 and CH-C1 passed. The exact wheel recipe failed because `build` was missing; after one recorded environment-only prerequisite installation, the unchanged wheel target and an additional wheel-only provenance check passed. One listed regenerated output, CH-C2, did not match the expected same-commit hash.

**Are you independent of this repository's development?**

Not an independent human reproducer. This is a separate Perplexity Computer verification session commissioned by the repository owner, not a session that implemented this checkout. Existing project context was available; no development artifacts or earlier execution results were used as substitutes for this run. Therefore this report must not, by itself, be counted as satisfying REPRODUCTION.md's independent-person requirement or closing FINAL-AUDIT item 11.

**Environment**

Isolated cloud Linux sandbox, hostname `space-sandbox`; the workspace initially contained only session context, memory and skills, with no repository or sibling checkout. The repository was freshly cloned into `/home/user/workspace/sarc-authority-derivation`. A new Python environment at `/home/user/workspace/reproduction-venv` was created with `python3.12 -m venv`; `PYTHONPATH` was unset. The exact wheel target created its own separate fresh `/tmp/sarc-p5-ac-smoke` environment and executed from `/tmp`; a further retained-wheel verification used a third fresh environment and confirmed every tested project import resolved to that environment's `site-packages`.

The initial empty workspace is observable, but platform/VM lifecycle attestation and physical-host history are not available. I cannot certify that the underlying machine/VM was never used in development. This is a qualification limitation, not a claimed compliance pass. The sandbox had 2 vCPUs (Intel Xeon @ 2.90 GHz), 7.8 GiB RAM, no swap, and roughly 11 GiB free disk initially. Environment evidence is in `03-environment.log` and `06-selected-python.log`.

**Commit sha you tested at**

`{sha}` (detached HEAD, unchanged throughout).

Repository: https://github.com/besanson/sarc-authority-derivation

**Operating system**

Ubuntu 26.04 LTS (Resolute Raccoon), x86_64; kernel `6.1.155+`, `#1 SMP PREEMPT_DYNAMIC Thu Dec 18 15:17:16 UTC 2025`. Git 2.53.0. The run began on 2026-09-14 UTC and completed its technical verification on 2026-09-14 at 22:02:07 UTC (2026-09-15 00:02:07 CEST).

**Python version**

CPython **3.12.13**, within the documented 3.11/3.12 range. The machine default was Python 3.14.3, used only for initial inspection/recording before selecting 3.12.13; it was not used for reproduction targets. Initial pip: 25.0.1. Resolved dependencies included pytest 9.1.1, Hypothesis 6.168.0, mutmut 3.8.0, jsonschema 4.26.0, SciPy 1.17.1, python-sat 1.9.dev15, PyYAML 6.0.3 and NumPy 2.5.3; complete before/after package inventories are in `12-final-state.log` and `20-integrity.log`.

**Commands you ran**

- [x] `bash bootstrap.sh`
- [x] `make quick-reproduce`
- [ ] `make release-check` (optional; not run for this repository)
- [x] `make package-smoke-test` (failed initially; passed on unchanged-target retry)
- [ ] `authority-bench` (full benchmark not run; `--help` was exercised)
- [x] The code/cloud multi-reduct example, CH-B1 (REPRODUCTION.md section 6)
- [x] The large-domain core-insufficiency example, CH-C1 (REPRODUCTION.md section 6b)
- [x] Other: additional retained wheel build/install, neutral-directory import-path verification, hashes and source-integrity checks

The exact substantive sequence below was executed through an external recorder. Each command's working directory, start time in UTC, exit code, wall-clock duration, combined stdout/stderr and SHA-256 are retained in `commands.jsonl` and the per-command logs; `command-ledger.md` lists every recorded command in full. The CH-B1 heredoc was extracted verbatim from REPRODUCTION.md, not rewritten. Activation/unsetting were performed in the wrapper scripts included in the bundle.

```bash
# Fresh clone and pinned checkout
git clone https://github.com/besanson/sarc-authority-derivation.git
cd sarc-authority-derivation
git checkout --detach 4a96769
git rev-parse HEAD
git status --porcelain=v1

# Environment selection, outside repository
python3.12 -m venv /home/user/workspace/reproduction-venv
source /home/user/workspace/reproduction-venv/bin/activate
unset PYTHONPATH

# Repository-root commands, exact documented targets
bash bootstrap.sh
make quick-reproduce
make package-smoke-test
# Above failed with: No module named build

{by_label['10-ch-b1']['command']}

python3 -m checkers.ch_c1_check

# Explicit recovery, after preserving the initial failure
python3 -m pip install build
make package-smoke-test
```

The supplemental retained build and verification commands are reproduced verbatim in `command-ledger.md` and `package-followup.sh`. The exact smoke target deletes its own wheel and environment on success; the additional build exists only to retain a hashable wheel and directly attest import paths. No repository code, Makefile, configuration or documentation was edited to obtain any result.

**Elapsed time**

Times below are external `time.monotonic()` wall-clock measurements of each recorded command, excluding subsequent log hashing/copying. Commands were run sequentially; short read-only monitoring/audit operations overlapped the long run. Hardware differs from the document's timing platform.

| Command/stage | Seconds | Elapsed | Exit |
|---|---:|---|---:|
{chr(10).join(timing_rows)}

Quick reproduction took **{seconds:.2f} seconds**, versus the documented 2,874.14 seconds: **{delta:.2f} seconds ({delta/60:.2f} minutes; {delta/2874.14*100:.1f}%) longer**. Bootstrap plus quick reproduction took {205.029958+seconds:.2f} seconds, versus the documented total of 3,053.27 seconds. The test suite itself reported 275.64 seconds. Standalone CH-C1 has no separately documented timing expectation. Timings for clone, setup, inspections and verification are in the complete command ledger.

**Output hashes you got**

Only actually regenerated outputs are claimed here; matching retained files are not counted as reproduced.

| File | Your sha256 | Comparison |
|---|---|---|
{chr(10).join(hash_rows)}

CH-B1 and CH-C1 also matched these hashes in the preserved first formal run. CH-C1's standalone rerun matched again; CH-C2's first-run and final values both had the same observed mismatching hash. For CH-C2 the documented expected SHA-256 is `750b42c192aab023439c462ec18b7fee09f74d15c72661f346295e4c10f3789f`.

Additional retained artifacts, with no reference hash specified by REPRODUCTION.md:

- `{wheel.name}`: `{wheel_hash}`
- `{sdist.name}`: `{sdist_hash}`

These are from the supplemental build, not the artifact deleted by the exact smoke target. Build-byte identity between these two builds was not assessed. Every recorded command-output hash is in `commands.jsonl` and `command-ledger.md`; `SHA256SUMS` covers the report and evidence bundle contents.

**Test/mutation results**

- **Bootstrap:** PASS, including the imported `sarc-suite-one-pass` baseline's release check; all four sibling SHAs matched their locks.
- **Quick reproduce:** `252 passed in 275.64s`; 0 failures, 0 errors, 0 skipped. `formal double-run byte-identical: OK`; `populated draft byte-identical to freshly regenerated: OK`; citation, typed-numerals, terminology and proof-status gates completed; final target message `quick-reproduce: ALL CHECKS PASS`.
- **Mutation:** this repository's mutation gate was deliberately not run. No reproduction claim is made for the documented 1229/1261 mutation score, even if a generated/retained report contains historical mutation information.
- **Wheel black box:** after the recorded prerequisite fix, exact target emitted `IMPORT_OK`, `DERIVE_OK ['a', 'b']` and `package-smoke-test: PASS`; `authority-bench --help` exited successfully. The supplementary check verified `authority_compiler`, its API and all enumerated local dependency modules were imported exclusively from the wheel-only environment's `site-packages`, with cwd `/tmp` and no `PYTHONPATH`.
- **CH-B1:** 15,120 reachable tuples; 6-of-10 core; `core sufficient: False`; exactly two 7-property reducts (core plus `branch` or `environment`); 1,014 subsets considered; `supported: true`. The section-6 snippet printed precisely those two reducts.
- **CH-C1:** 27,000 reachable tuples; 35 candidates; core cardinality 4; `is_core_sufficient: false`; `supported: true`; minimum cardinality 9; five contracts found under the cap of five. This is a bounded lower-bound enumeration, not a claim of exhaustive multiplicity. CH-B1 and CH-C1 used direct source imports as instructed, not the wheel API.

**Deviations from REPRODUCTION.md's own expectations**

1. **Missing wheel-build prerequisite (observed failure).** The unmodified `make package-smoke-test` failed immediately with `/home/user/workspace/reproduction-venv/bin/python3: No module named build` and make exit 2. `bootstrap.sh` does not install `build`; the CI package job does. Installing `build` in the external reproduction environment and retrying the unchanged target succeeded. Thus the documented bare-clone sequence was not fully self-sufficient. The failed and recovered runs are both retained.
2. **Same-commit CH-C2 hash mismatch (observed).** Six cost fields serialized as `9.153` instead of `9.152999999999999`; the exact diff is in `generated-output-diff.patch`. This is a byte-level failure of the documented expected hash, despite no substantive CH-C2 result-field change: it remains the registered `negative_tie`, with `supported: false`. The double-run gate compares the two new runs with each other, not their hashes against the committed hash table, so it passed without resolving this discrepancy. No source fix or output normalization was applied.
3. **Additional generated-file differences.** CH-B2 serialized two costs as `6.1240000000000006` rather than `6.124`; `derivation_output.json` and `derivation_output_v2.json` updated `generated_at_head_sha` from `63ec6034b488566684c24dcbb974fdb5f0772b5c` to the tested commit. These four tracked JSON files, including CH-C2, were the only tracked-file changes. They are command-generated outputs, not manual edits, and were deliberately not restored or hidden.
4. **Elapsed time differs.** Quick reproduction was {delta/60:.2f} minutes slower than the stated measurement. Timing variability is permitted by the document, but the difference is recorded explicitly.
5. **Expected-hash coverage is overstated in the document.** Its claim that every listed file is regenerated and part of the formal double-run does not match the Makefile. Quick reproduction regenerates the populated draft separately and regenerates the three listed checker files via `formal`, but does not run AuthorityBench or the v8 exhaustive attempt. Those two files remained committed inputs and their hashes are not claimed as fresh reproduction. No exhaustive attempt was run, consistent with the document's warning and the user's requested scope.
6. **“Pinned toolchain” is incomplete.** SciPy is pinned and siblings are commit-pinned, but bootstrap leaves several tools and runtime dependencies unpinned. The actual resolved versions are recorded; they were not manually changed to chase expected hashes.
7. **Independence and filing remain unfulfilled.** This run is not an independent person's attestation, machine-history independence is unverified, and this report has not been filed as a GitHub issue. No change to FINAL-AUDIT item 11 is asserted.

**Anything else worth noting**

The user requested no repository modification. No manual repository edits, commits, restores, patches or pushes were performed; the prescribed commands necessarily rewrote generated outputs and created ignored build/test artifacts. A direct `git diff --exit-code -- . ':(exclude)out'` returned success. The four generated tracked-output differences above remain visible; it would be inaccurate to call the working tree wholly unchanged.

The retained report from `quick-reproduce` contains a paper-freshness description referring to a `make release-check` run even though the actual executed target was `quick-reproduce`. Its wording is not evidence that the optional authority-derivation release/mutation gate ran. This report's claims are based on the command ledger and actual logs instead.

The evidence bundle contains the original procedure/template/Makefile snapshots in the inspection logs, complete target output, exact wrapper scripts, first-formal-run output, stage snapshots, package inventories, retained wheel/sdist, generated-output diff, expected-hash verification and SHA-256 manifest. Preliminary discovery and status-polling shell calls are separately transcribed in `tool-command-transcript.md`; unlike substantive commands, they were not all independently stopwatch-timed. A harmless `printf` heading error in evidence-copy command 13 is retained; hashing, copying and test-count extraction still succeeded. An initial ordinary `nohup` launch did not persist and executed no recorded reproduction stage; the successful run used a separate process session via `setsid`.

**Disposition:** technical reproduction with documented deviations and a recovered packaging prerequisite, not certification of a fully independent reproduction. This is an issue-template-formatted draft, not a submitted issue.
"""
(E / "reproduction-report.md").write_text(report)
ledger = ["# Reproduction command ledger", "",
          "Exact recorded commands, sorted by UTC start time. Each stdout/stderr log is raw combined output; elapsed time is for the full displayed shell command, not each subcommand individually.", ""]
for rec in sorted(records, key=lambda r: r["start_utc"]):
    ledger.extend([
        f"## {rec['label']}", "",
        f"- Working directory: `{rec['cwd']}`",
        f"- Started: `{rec['start_utc']}`",
        f"- Wall-clock seconds: `{rec['elapsed_seconds']}`",
        f"- Exit code: `{rec['exit_code']}`",
        f"- Combined output: `{rec['output_file']}`",
        f"- Output SHA-256: `{rec['output_sha256']}`", "",
        "```bash", rec["command"], "```", "",
    ])
(E / "command-ledger.md").write_text("\n".join(ledger))
# Untimed setup/poll commands are transcribed separately from the session tool inputs.
assert (E / "tool-command-transcript.md").exists()
print(json.dumps({"report": str(E / "reproduction-report.md"),
                  "recorded_commands_verified": len(records),
                  "source_unchanged": True,
                  "listed_regenerated_hash_matches": 3,
                  "listed_regenerated_hash_mismatches": 1,
                  "listed_retained_not_claimed": 2}, indent=2))
