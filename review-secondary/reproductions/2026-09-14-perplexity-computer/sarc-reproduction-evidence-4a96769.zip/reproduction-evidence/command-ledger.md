# Reproduction command ledger

Exact recorded commands, sorted by UTC start time. Each stdout/stderr log is raw combined output; elapsed time is for the full displayed shell command, not each subcommand individually.

## 01-clone

- Working directory: `/home/user/workspace`
- Started: `2026-09-14T20:40:25.858747+00:00`
- Wall-clock seconds: `0.679047`
- Exit code: `0`
- Combined output: `01-clone.log`
- Output SHA-256: `10113d37b8f2d886bc13c924d82f084f5b623d36f2f4733628386a4502dac446`

```bash
git clone https://github.com/besanson/sarc-authority-derivation.git && cd sarc-authority-derivation && git checkout --detach 4a96769 && git rev-parse HEAD && git status --porcelain=v1 && printf "\n--- REPRODUCTION ---\n" && cat REPRODUCTION.md && printf "\n--- ISSUE TEMPLATES ---\n" && rg --files .github/ISSUE_TEMPLATE
```

## 03-environment

- Working directory: `/home/user/workspace`
- Started: `2026-09-14T20:40:34.517529+00:00`
- Wall-clock seconds: `0.041531`
- Exit code: `0`
- Combined output: `03-environment.log`
- Output SHA-256: `903c640cc6a5f6f4fb59f70aa660c8e5e06ad9998b0e0fa323098addb1fef9d8`

```bash
date -u --iso-8601=seconds; uname -a; cat /etc/os-release; python3 --version; command -v python3.11 python3.12 uv make gcc || true; ls -ld /opt /opt/* /usr/local/bin/python* 2>/dev/null; lscpu; free -h; df -h /home/user/workspace /tmp; env | sort | sed -n "/^LANG=/p;/^LC_/p;/^PYTHONPATH=/p;/^VIRTUAL_ENV=/p"; git --version
```

## 02-instructions

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T20:40:34.518441+00:00`
- Wall-clock seconds: `0.010725`
- Exit code: `0`
- Combined output: `02-instructions.log`
- Output SHA-256: `87eeb4db105e0a4438bafec1a8c3d8ab46d829becba147217826313f7f713761`

```bash
cat .github/ISSUE_TEMPLATE/reproduction-report.md; printf "\n--- BOOTSTRAP ---\n"; cat bootstrap.sh; printf "\n--- MAKEFILE ---\n"; cat Makefile; printf "\n--- PACKAGE CONFIGURATION ---\n"; cat pyproject.toml; printf "\n--- SMOKE CHECK ---\n"; cat authority_compiler_smoke.py
```

## 04-baseline

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T20:40:43.964490+00:00`
- Wall-clock seconds: `0.089779`
- Exit code: `0`
- Combined output: `04-baseline.log`
- Output SHA-256: `8248e0e6b01cbe93d2e9307623d252a3cdd01b1e919d39e36d5ab056953a6f78`

```bash
sed -n "/^package-smoke-test:/,/^clean:/p" Makefile; cat pyproject.toml; cat authority_compiler_smoke.py; git ls-files -z | xargs -0 sha256sum; printf "\n--- PYTHON 3.12 ---\n"; python3.12 --version
```

## 05-create-venv

- Working directory: `/home/user/workspace`
- Started: `2026-09-14T20:41:17.031366+00:00`
- Wall-clock seconds: `2.163518`
- Exit code: `0`
- Combined output: `05-create-venv.log`
- Output SHA-256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

```bash
python3.12 -m venv /home/user/workspace/reproduction-venv
```

## 06-selected-python

- Working directory: `/home/user/workspace`
- Started: `2026-09-14T20:41:19.254026+00:00`
- Wall-clock seconds: `0.228694`
- Exit code: `0`
- Combined output: `06-selected-python.log`
- Output SHA-256: `78310f00198e5ed6a11f10ee74c70a653b39525fdbb4d33124e338b175d824a0`

```bash
python3 --version; pip --version; command -v python3 pip; printenv VIRTUAL_ENV; test -z "${PYTHONPATH:-}"
```

## 07-bootstrap

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T20:41:19.540165+00:00`
- Wall-clock seconds: `205.029958`
- Exit code: `0`
- Combined output: `07-bootstrap.log`
- Output SHA-256: `bc18e7c56ac0a0d576852a3d07ab6e4ce712ddb19ec03b3e9202ea2270ba1381`

```bash
bash bootstrap.sh
```

## 08-quick-reproduce

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T20:44:44.651006+00:00`
- Wall-clock seconds: `3911.154207`
- Exit code: `0`
- Combined output: `08-quick-reproduce.log`
- Output SHA-256: `04ecc240d402ab820e754afc4989dbd4f9412bca70d62412d83bd34fff500666`

```bash
make quick-reproduce
```

## 13-first-formal-evidence

- Working directory: `/home/user/workspace`
- Started: `2026-09-14T21:25:48.931680+00:00`
- Wall-clock seconds: `0.016927`
- Exit code: `0`
- Combined output: `13-first-formal-evidence.log`
- Output SHA-256: `c014503da967f0a98c7a2c7f85bc006419fc950b86b64dc6a7017acb2d4e895e`

```bash
printf "--- First formal-run hashes ---\n"; sha256sum /tmp/sarc-p5-quick-reproduce-formal-1/ch_b1_check.json /tmp/sarc-p5-quick-reproduce-formal-1/ch_c1_check.json /tmp/sarc-p5-quick-reproduce-formal-1/ch_c2_check.json; cp -a /tmp/sarc-p5-quick-reproduce-formal-1 /home/user/workspace/reproduction-evidence/formal-run-1; rg "252 passed|collected 252" /home/user/workspace/reproduction-evidence/08-quick-reproduce.log
```

## 14-first-ch-c2-diff

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T21:25:53.369029+00:00`
- Wall-clock seconds: `0.033542`
- Exit code: `0`
- Combined output: `14-first-ch-c2-diff.log`
- Output SHA-256: `ce508d082fe0809b5d6410bc15de91e03e1813f331f71041df2bb90f8b9861f9`

```bash
git diff -- out/checkers/ch_c2_check.json; cat /home/user/workspace/reproduction-evidence/formal-run-1/ch_c2_check.json
```

## 09-package-smoke-test

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T21:49:55.867571+00:00`
- Wall-clock seconds: `0.016231`
- Exit code: `2`
- Combined output: `09-package-smoke-test.log`
- Output SHA-256: `7b87305d16c1b56b464863c682e254490ccf6937e934a5fc8b5e33034c44345b`

```bash
make package-smoke-test
```

## 10-ch-b1

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T21:49:55.944354+00:00`
- Wall-clock seconds: `8.976989`
- Exit code: `0`
- Combined output: `10-ch-b1.log`
- Output SHA-256: `d9a093ebdd098cc14de5c2961802531812eac7170b31f9daa141d9d9de1d4a5d`

```bash
python3 <<'EOF'
from domain_v4 import CANDIDATE_PROPERTIES_V4, executable_reachable_tuples_v4
from losses_v4 import load_loss_registry_v4
from reduct import compute_core, exact_reducts, sufficiency

reachable = executable_reachable_tuples_v4()
registry = load_loss_registry_v4()

core, redundant, _witnesses = compute_core(reachable, registry, CANDIDATE_PROPERTIES_V4)
print(f"core ({len(core)} of {len(CANDIDATE_PROPERTIES_V4)} candidates):", sorted(core))

is_sufficient, _certificate = sufficiency(tuple(sorted(core)), reachable, registry)
print("core sufficient:", is_sufficient)

reducts, subsets_considered = exact_reducts(CANDIDATE_PROPERTIES_V4, reachable, registry)
print(f"reducts ({subsets_considered} subsets tested after pruning):")
for r in sorted(sorted(r) for r in reducts):
    print(" ", r)
EOF
```

## 11-ch-c1

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T21:50:04.981313+00:00`
- Wall-clock seconds: `454.937846`
- Exit code: `0`
- Combined output: `11-ch-c1.log`
- Output SHA-256: `602806ec212a529fea46e3751e82a6fc5f90964ffb546996febb2290101bbb09`

```bash
python3 -m checkers.ch_c1_check
```

## 12-final-state

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T21:57:39.989665+00:00`
- Wall-clock seconds: `0.735988`
- Exit code: `0`
- Combined output: `12-final-state.log`
- Output SHA-256: `a4f08e3ebd2cd70b60c13081a0ce1ae610a604aaddf759f97a221290a1f60b27`

```bash
python3 --version; pip freeze; git rev-parse HEAD; git status --porcelain=v1; git diff --stat; git diff --exit-code -- . ":(exclude)out"; sha256sum paper5-authority-derivation-draft-v0.5-populated.md out/checkers/ch_b1_check.json out/checkers/ch_c1_check.json out/checkers/ch_c2_check.json out/results/authority_bench_v6_1.json out/results/v8_exhaustive_attempt.json; cat out/checkers/ch_b1_check.json out/checkers/ch_c1_check.json; git diff -- out
```

## 15-install-build

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T22:01:52.915957+00:00`
- Wall-clock seconds: `0.669787`
- Exit code: `0`
- Combined output: `15-install-build.log`
- Output SHA-256: `7981403f691645f12ee6c6e40be292dcd43f80d1e0574de59ab7105e4205f468`

```bash
python3 -m pip install build
```

## 16-package-smoke-retry

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T22:01:53.645461+00:00`
- Wall-clock seconds: `6.198915`
- Exit code: `0`
- Combined output: `16-package-smoke-retry.log`
- Output SHA-256: `d442395302ef5bed8d880b47fab00767b5787e5fbf64a66d5ac61dd8fde3a72d`

```bash
make package-smoke-test
```

## 17-retained-build

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T22:01:59.905384+00:00`
- Wall-clock seconds: `3.083318`
- Exit code: `0`
- Combined output: `17-retained-build.log`
- Output SHA-256: `1b2512433088e13fac2bc892b00921c6b05e2cc6260690933ff631e507e606bd`

```bash
python3 -m build --outdir /home/user/workspace/reproduction-evidence/distributions; sha256sum /home/user/workspace/reproduction-evidence/distributions/*
```

## 18-retained-wheel-install

- Working directory: `/home/user/workspace`
- Started: `2026-09-14T22:02:03.049958+00:00`
- Wall-clock seconds: `2.919313`
- Exit code: `0`
- Combined output: `18-retained-wheel-install.log`
- Output SHA-256: `d6e4f554ab4c425dbcee4c9a4c90da2efc76abe0a91ce2e00c5ca342be00d20c`

```bash
python3 -m venv /home/user/workspace/wheel-verification-venv && /home/user/workspace/wheel-verification-venv/bin/python -m pip install /home/user/workspace/reproduction-evidence/distributions/*.whl
```

## 19-wheel-import-provenance

- Working directory: `/tmp`
- Started: `2026-09-14T22:02:06.028116+00:00`
- Wall-clock seconds: `0.562176`
- Exit code: `0`
- Combined output: `19-wheel-import-provenance.log`
- Output SHA-256: `b14daa62166adb9d3966a6011661253c4677be01282f63079d7526afea96f010`

```bash
/home/user/workspace/wheel-verification-venv/bin/python - <<'PY'
import os, sys, importlib, importlib.metadata
print('cwd:', os.getcwd())
print('python:', sys.version)
print('sys.path:', sys.path)
print('PYTHONPATH:', os.environ.get('PYTHONPATH'))
print('distribution:', importlib.metadata.version('sarc-authority-derivation'))
for name in ['authority_compiler', 'authority_compiler.api', 'reduct', 'synthesis', 'participation', 'discernibility', 'losses', 'domain', 'mining_baseline', 'authority_bench']:
    m = importlib.import_module(name)
    print(name, m.__file__)
    assert '/home/user/workspace/wheel-verification-venv/lib/python3.12/site-packages/' in m.__file__
print('WHEEL_ONLY_IMPORT_PATHS_OK')
PY
/home/user/workspace/wheel-verification-venv/bin/python - < /home/user/workspace/sarc-authority-derivation/authority_compiler_smoke.py
/home/user/workspace/wheel-verification-venv/bin/authority-bench --help
/home/user/workspace/wheel-verification-venv/bin/python -m pip freeze
```

## 20-integrity

- Working directory: `/home/user/workspace/sarc-authority-derivation`
- Started: `2026-09-14T22:02:06.645291+00:00`
- Wall-clock seconds: `0.706699`
- Exit code: `0`
- Combined output: `20-integrity.log`
- Output SHA-256: `e65736473367fa32647dd14e005cea87da72820bb17b593d6f994351c6b96670`

```bash
git rev-parse HEAD; git status --porcelain=v1 --untracked-files=all; git diff --stat; git diff --exit-code -- . ":(exclude)out"; git diff -- out; python3 -m pip freeze; sha256sum paper5-authority-derivation-draft-v0.5-populated.md out/checkers/ch_b1_check.json out/checkers/ch_c1_check.json out/checkers/ch_c2_check.json out/results/authority_bench_v6_1.json out/results/v8_exhaustive_attempt.json
```
