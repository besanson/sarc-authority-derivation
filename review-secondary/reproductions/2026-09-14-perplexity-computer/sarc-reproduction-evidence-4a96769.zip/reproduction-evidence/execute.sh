#!/usr/bin/env bash
set -u
E=/home/user/workspace/reproduction-evidence
R=/home/user/workspace/sarc-authority-derivation
python3 "$E/run.py" 05-create-venv 'python3.12 -m venv /home/user/workspace/reproduction-venv'
source /home/user/workspace/reproduction-venv/bin/activate
unset PYTHONPATH
python3 "$E/run.py" 06-selected-python 'python3 --version; pip --version; command -v python3 pip; printenv VIRTUAL_ENV; test -z "${PYTHONPATH:-}"'
python3 "$E/run.py" 07-bootstrap 'bash bootstrap.sh' --cwd "$R"
python3 "$E/run.py" 08-quick-reproduce 'make quick-reproduce' --cwd "$R"
python3 "$E/run.py" 09-package-smoke-test 'make package-smoke-test' --cwd "$R"
python3 "$E/run.py" 10-ch-b1 "$(sed -n '/^python3 <<'\''EOF'\''$/,/^EOF$/p' "$R/REPRODUCTION.md")" --cwd "$R"
python3 "$E/run.py" 11-ch-c1 'python3 -m checkers.ch_c1_check' --cwd "$R"
python3 "$E/run.py" 12-final-state 'python3 --version; pip freeze; git rev-parse HEAD; git status --porcelain=v1; git diff --stat; git diff --exit-code -- . ":(exclude)out"; sha256sum paper5-authority-derivation-draft-v0.5-populated.md out/checkers/ch_b1_check.json out/checkers/ch_c1_check.json out/checkers/ch_c2_check.json out/results/authority_bench_v6_1.json out/results/v8_exhaustive_attempt.json; cat out/checkers/ch_b1_check.json out/checkers/ch_c1_check.json; git diff -- out' --cwd "$R"
printf 'EXECUTION_FINISHED\n'
