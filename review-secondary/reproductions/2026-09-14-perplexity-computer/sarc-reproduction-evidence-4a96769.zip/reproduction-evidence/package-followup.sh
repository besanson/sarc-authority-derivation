#!/usr/bin/env bash
set -eu
E=/home/user/workspace/reproduction-evidence
R=/home/user/workspace/sarc-authority-derivation
source /home/user/workspace/reproduction-venv/bin/activate
unset PYTHONPATH
python3 "$E/run.py" 15-install-build 'python3 -m pip install build' --cwd "$R"
python3 "$E/run.py" 16-package-smoke-retry 'make package-smoke-test' --cwd "$R"
# Preserve an additional build because the exact smoke-test target removes its artifacts.
python3 "$E/run.py" 17-retained-build 'python3 -m build --outdir /home/user/workspace/reproduction-evidence/distributions; sha256sum /home/user/workspace/reproduction-evidence/distributions/*' --cwd "$R"
python3 "$E/run.py" 18-retained-wheel-install 'python3 -m venv /home/user/workspace/wheel-verification-venv && /home/user/workspace/wheel-verification-venv/bin/python -m pip install /home/user/workspace/reproduction-evidence/distributions/*.whl'
python3 "$E/run.py" 19-wheel-import-provenance "/home/user/workspace/wheel-verification-venv/bin/python - <<'PY'
import os, sys, importlib, importlib.metadata
print('cwd:', os.getcwd())
print('python:', sys.version)
print('sys.path:', sys.path)
print('PYTHONPATH:', os.environ.get('PYTHONPATH'))
print('distribution:', importlib.metadata.version('sarc-authority-derivation'))
for name in ['authority_compiler', 'authority_compiler.api', 'reduct', 'synthesis', 'participation', 'discernibility', 'losses', 'domain', 'mining_baseline', 'authority_bench']:
    m = importlib.import_module(name)
    print(name, m.__file__)
    assert '/home/user/workspace/wheel-verification-venv/lib/python3.12/site-packages/' in m.__file__
print('WHEEL_ONLY_IMPORT_PATHS_OK')
PY
/home/user/workspace/wheel-verification-venv/bin/python - < /home/user/workspace/sarc-authority-derivation/authority_compiler_smoke.py
/home/user/workspace/wheel-verification-venv/bin/authority-bench --help
/home/user/workspace/wheel-verification-venv/bin/python -m pip freeze" --cwd /tmp
python3 "$E/run.py" 20-integrity 'git rev-parse HEAD; git status --porcelain=v1 --untracked-files=all; git diff --stat; git diff --exit-code -- . ":(exclude)out"; git diff -- out; python3 -m pip freeze; sha256sum paper5-authority-derivation-draft-v0.5-populated.md out/checkers/ch_b1_check.json out/checkers/ch_c1_check.json out/checkers/ch_c2_check.json out/results/authority_bench_v6_1.json out/results/v8_exhaustive_attempt.json' --cwd "$R"
