# Supplemental shell-command transcript

Setup, process launch and read-only progress checks outside the timed recorder are transcribed below in execution order. Their individual elapsed times were not independently measured. All commands that performed reproduction computations, dependency installation, substantive output hashing or package verification are separately retained with exact commands, timing and raw output in `commands.jsonl` and `command-ledger.md`. Commands internal to the prescribed bootstrap/Make targets are defined by the unmodified source scripts; emitted commands and results are in their full logs.

This transcript excludes unrelated context retrieval, skill loading, memory operations and final deliverable sharing. Report assembly and integrity validation are included as ancillary operations. No credential values are included.

## Initial discovery

```bash
pplx connector list select:github_mcp_direct; printf '\n--- ENVIRONMENT ---\n'; pwd; uname -a; cat /etc/os-release; python3 --version; git --version; printf '\n--- WORKSPACE ---\n'; ls -la; printf '\n--- REMOTE ---\n'; git ls-remote https://github.com/besanson/sarc-authority-derivation.git
```

The initial workspace contained `current_session_context`, `memory` and `skills`, with no repository. The remote HEAD was `4a9676966aecb3d18cec6411decd5b9cfa8a7320`. OS/Python and hardware observations were recaptured in the timed environment commands 03 and 06.

## Read the captured build instructions

```bash
sed -n '155,520p' reproduction-evidence/02-instructions.log
```

## Launch and early monitoring

```bash
nohup bash /home/user/workspace/reproduction-evidence/execute.sh > /home/user/workspace/reproduction-evidence/execution-console.log 2>&1 & echo "Reproduction recorder PID: $!"
```

This returned PID 823 but did not persist; no recorded reproduction stage ran under it.

```bash
tail -n 35 reproduction-evidence/07-bootstrap.log; printf '\n--- RECORDED COMPLETIONS ---\n'; tail -n 3 reproduction-evidence/commands.jsonl; printf '\n--- ACTIVE PROCESSES ---\n'; ps -eo pid,ppid,etime,pcpu,args | rg 'execute.sh|bootstrap|pip install|release-check|pytest|ch_c'
```

The bootstrap log did not yet exist and no reproduction process was active.

```bash
setsid nohup bash /home/user/workspace/reproduction-evidence/execute.sh > /home/user/workspace/reproduction-evidence/execution-console.log 2>&1 < /dev/null & pid=$!; sleep 2; ps -p "$pid" -o pid,ppid,sid,etime,comm; tail -n 6 /home/user/workspace/reproduction-evidence/execution-console.log
```

The successful persistent process had PID 845. Its entire computation sequence is in `execute.sh` and ledger entries 05–12.

```bash
tail -n 45 reproduction-evidence/07-bootstrap.log; tail -n 4 reproduction-evidence/commands.jsonl; ps -eo pid,ppid,etime,pcpu,comm | tail -n 20

head -n 65 reproduction-evidence/07-bootstrap.log; tail -n 12 reproduction-evidence/07-bootstrap.log; cat reproduction-evidence/06-selected-python.log; rg -n 'build|pip install|apt-get' sarc-suite-one-pass/bootstrap.sh; ps -p 845 -o pid,etime,comm

tail -n 4 reproduction-evidence/commands.jsonl; tail -n 18 reproduction-evidence/07-bootstrap.log; if test -f reproduction-evidence/08-quick-reproduce.log; then tail -n 18 reproduction-evidence/08-quick-reproduce.log; fi; ps -eo pid,ppid,etime,pcpu,comm | rg 'python|make|bash' | head -n 25

tail -n 15 reproduction-evidence/08-quick-reproduce.log; ps -p 845 -o pid,etime,comm; tail -n 1 reproduction-evidence/commands.jsonl
```

## Formal-check progress

```bash
tail -n 20 reproduction-evidence/08-quick-reproduce.log; tail -n 2 reproduction-evidence/commands.jsonl; ps -eo pid,ppid,etime,pcpu,comm | rg 'python|make|bash' | head -n 20; date -u --iso-8601=seconds

tail -n 22 reproduction-evidence/08-quick-reproduce.log; tail -n 4 reproduction-evidence/commands.jsonl; if test -f reproduction-evidence/09-package-smoke-test.log; then cat reproduction-evidence/09-package-smoke-test.log; fi; ps -eo pid,ppid,etime,pcpu,comm | rg 'python|make|bash' | head -n 20; date -u --iso-8601=seconds
```

First-formal-run copying/hashing and CH-C2 comparison were timed separately as entries 13 and 14. Their numbering is not chronological because they were additional observations while entry 08 was running; UTC timestamps establish order.

```bash
tail -n 6 reproduction-evidence/commands.jsonl; tail -n 20 reproduction-evidence/08-quick-reproduce.log; if test -f reproduction-evidence/09-package-smoke-test.log; then cat reproduction-evidence/09-package-smoke-test.log; fi; if test -f reproduction-evidence/10-ch-b1.log; then cat reproduction-evidence/10-ch-b1.log; fi; ps -eo pid,ppid,etime,pcpu,comm | rg 'python|make|bash' | head -n 20; date -u --iso-8601=seconds

tail -n 5 reproduction-evidence/commands.jsonl; tail -n 25 reproduction-evidence/08-quick-reproduce.log; for f in reproduction-evidence/09-package-smoke-test.log reproduction-evidence/10-ch-b1.log; do if test -f "$f"; then cat "$f"; fi; done; ps -eo pid,ppid,etime,pcpu,comm | rg 'python|make|bash' | head -n 20; date -u --iso-8601=seconds
```

## Packaging follow-up

```bash
tail -n 3 reproduction-evidence/commands.jsonl; tail -n 4 reproduction-evidence/execution-console.log; if rg -q '^EXECUTION_FINISHED$' reproduction-evidence/execution-console.log; then setsid nohup bash /home/user/workspace/reproduction-evidence/package-followup.sh > /home/user/workspace/reproduction-evidence/package-followup-console.log 2>&1 < /dev/null & pid=$!; sleep 2; ps -p "$pid" -o pid,etime,comm; fi

sed -n '1,120p' reproduction-evidence/12-final-state.log; rg -n '^diff --git|^[-+]  |^[-+]    |core_cardinality|minimum_cardinality|is_core_sufficient|reachable_tuples_swept' reproduction-evidence/12-final-state.log

tail -n 5 reproduction-evidence/commands.jsonl; tail -n 15 reproduction-evidence/package-followup-console.log; if test -f reproduction-evidence/16-package-smoke-retry.log; then tail -n 25 reproduction-evidence/16-package-smoke-retry.log; fi

tail -n 4 reproduction-evidence/commands.jsonl; if test -f reproduction-evidence/19-wheel-import-provenance.log; then cat reproduction-evidence/19-wheel-import-provenance.log; fi; if test -f reproduction-evidence/20-integrity.log; then head -n 20 reproduction-evidence/20-integrity.log; fi; rg -n 'byte-identical|252 passed|ALL CHECKS PASS' reproduction-evidence/08-quick-reproduce.log
```

## Report assembly and review

```bash
python3 /home/user/workspace/reproduction-evidence/assemble_report.py; wc -l /home/user/workspace/reproduction-evidence/reproduction-report.md /home/user/workspace/reproduction-evidence/command-ledger.md /home/user/workspace/reproduction-evidence/tool-command-transcript.md; sed -n '1,95p' /home/user/workspace/reproduction-evidence/reproduction-report.md; printf '\n--- RETAINED BUILD HASHES ---\n'; tail -n 3 /home/user/workspace/reproduction-evidence/17-retained-build.log

rg --files current_session_context/tool_calls/bash | head -n 12; p=$(rg --files current_session_context/tool_calls/bash | rg '/input_' | head -n 1); if test -n "$p"; then head -c 1800 "$p"; fi; sed -n '94,158p' reproduction-evidence/reproduction-report.md

rg --files current_session_context/tool_calls | rg 'input|\.json$' | head -n 25
```

The environment did not materialize shell input JSON files, so this supplemental transcript was transcribed from the visible session commands rather than exported from those files. The primary timed ledger and raw computation logs were created directly during execution, not reconstructed. The first transcript-generation attempt produced only a header; it was replaced with this explicit transcript before sharing.

## Evidence sealing

```bash
set -euo pipefail
python3 /home/user/workspace/reproduction-evidence/assemble_report.py
(cd /home/user/workspace/reproduction-evidence && rg --files --hidden -0 -g '!SHA256SUMS' | sort -z | xargs -0 sha256sum > SHA256SUMS && sha256sum --check SHA256SUMS | tail -n 5)
python3 -m zipfile -c /home/user/workspace/sarc-reproduction-evidence-4a96769.zip /home/user/workspace/reproduction-evidence
python3 -m zipfile -t /home/user/workspace/sarc-reproduction-evidence-4a96769.zip
sha256sum /home/user/workspace/sarc-reproduction-evidence-4a96769.zip /home/user/workspace/reproduction-evidence/reproduction-report.md
du -h /home/user/workspace/sarc-reproduction-evidence-4a96769.zip
```
